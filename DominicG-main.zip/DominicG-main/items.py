import pygame
import globals

class Items():
    def __init__(self):
        pass
        # code to allow me to easily blit buttons centrally to the screen even if dimensions change
    def centre (self, x, y, width, height):
        # code to centre item
        self.x = x
        self.y = y
        if x == 'centre' or x == 'center':
            self.x = globals.WIDTH//2 - width//2
        if y == 'centre' or y == 'center':
            self.y = globals.HEIGHT//2 - height//2
class Button(Items):
    def __init__(self, x, y, width, height, text, colourset, font_size, action):
        self.centre(x, y, width, height)
        # defining button rectangle
        self.rect = pygame.Rect(self.x, self.y, width, height)
        self.text = text
        # colour themes text, bgc 1/2 so I don't have to define all colours every instance
        if colourset == 'black':
            self.bg1 = globals.BLACK
            self.bg2 = globals.WHITE
            self.tc1 = globals.WHITE
            self.tc2 = globals.BLACK
        if colourset == 'blue':
            self.bg1 = globals.BLUE
            self.bg2 = globals.WHITE
            self.tc1 = globals.WHITE
            self.tc2 = globals.BLACK
        if colourset == 'gray':
            self.bg1 = globals.GRAY
            self.bg2 = globals.GRAY
            self.tc1 = globals.WHITE
            self.tc2 = globals.RED
        self.font = pygame.font.Font(None, font_size)
        self.action = action
    def draw(self, window):
        # draws button rectang and pastes text in center
        pygame.draw.rect(window, self.bg_colour, self.rect)
        text_surface = self.font.render(self.text, True, self.text_colour)
        text_rect = text_surface.get_rect(center = self.rect.center)
        window.blit(text_surface, text_rect)
    def button_colour(self):
        # checks mouse position changes bg colour if hovering and if button is pressed actions button
        mouse_pos = pygame.mouse.get_pos()
        hoverin = self.rect.collidepoint(mouse_pos)
        if hoverin == True:
            self.bg_colour = self.bg2
            self.text_colour = self.tc2
        if hoverin == False:
            self.bg_colour = self.bg1
            self.text_colour = self.tc1
    def mouse_click(self, event):
        # when mouse clicked checks if mouse is over button instance if so returns action for nextstate
        mouse_pos = pygame.mouse.get_pos()
        hoverin = self.rect.collidepoint(mouse_pos)
        if hoverin == True and event.type == pygame.MOUSEBUTTONDOWN:
                return self.action
