import pygame
#just declaring all my images for platforms
module1 = pygame.image.load('Graphics/Terrain tiles/Section 1.png')
module2 =  pygame.transform.flip(module1, True, False)

module3 = pygame.image.load('Graphics/Terrain tiles/Section 2.png')
module4  =  pygame.transform.flip(module3, True, False)
longfloor = pygame.image.load('Graphics/Terrain tiles/Long Floor.png')

blank1 = pygame.image.load('Graphics/Terrain tiles/Blank tile1.png')

insidecorner1 = pygame.image.load('Graphics/Terrain tiles/Section 1.png')
insidecorner2 =  pygame.transform.flip(insidecorner1, True, False)

outsidecornerleft = pygame.image.load('Graphics/Terrain tiles/Left corner tile.png')
outsidecornerright = pygame.transform.flip(outsidecornerleft, True, False)

pointybit = pygame.image.load('Graphics/Terrain tiles/Stick tile.png')
stick = pygame.image.load('Graphics/Terrain tiles/Stick.png')

nipple = pygame.image.load('Graphics/Terrain tiles/nipple.png')
rnipple =  pygame.transform.rotate(nipple, 270)
tidbit = pygame.image.load('Graphics/Terrain tiles/Thinbit.png')


rightwall = pygame.image.load('Graphics/Terrain tiles/RIght wall segment.png')
leftwall = pygame.transform.flip(rightwall, True, False)

cap1 = pygame.image.load('Graphics/Terrain tiles/Shite.png')
cap_1 = pygame.transform.flip(cap1, True, False)
cap2 = pygame.image.load('Graphics/Terrain tiles/Shite2.png')

chunk1 = pygame.image.load('Graphics/Terrain tiles/Chunk1.png')
chunk2 = pygame.image.load('Graphics/Terrain tiles/Chunk2.png')
chunk_2 = pygame.transform.flip(chunk2, True, False)
chunk3 = pygame.image.load('Graphics/Terrain tiles/Chunk3.png')
chunk_3 = pygame.transform.flip(chunk3, True, True)
chunk4 = pygame.image.load('Graphics/Terrain tiles/Chunk4.png')

widget = pygame.image.load('Graphics/Terrain tiles/widget.png')
leg = pygame.image.load('Graphics/Terrain tiles/Leg.png')

islandstrip = pygame.image.load('Graphics/Terrain tiles/island segment.png')

basiccorner = pygame.image.load('Graphics/Terrain tiles/wdsfsdf.png')
standardtile = pygame.image.load('Graphics/Terrain tiles/Standard tile.png')
