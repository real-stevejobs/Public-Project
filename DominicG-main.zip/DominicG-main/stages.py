import pygame
import frames
import globals
import sprites
import states
import terrain


class Stages():
    def __init__(self):
        self.nextstage = None  # sets nextstage to None to stay on current stage
        self.bg = pygame.image.load('Graphics/Backgrounds/Prettycave.png')

    def inputs(self,event):
        self.player.inputs(event) # recieves inputs from states and passes through to player

    def update(self):
        self.player.update(self.platforms, self.sprites) # recieves inputs from states and passes through to player
        self.updatesprites(self.platforms, self.sprites)
        self.nextstage = self.player.restage(self.portals)
    def drawlist(self, window, list): # for drawing lists of sprites eg platforms
        self.list = list
        for i in self.list:
            i.draw(window)

    def updatesprites(self, platform, list): # for drawing lists of sprites eg platforms
        self.list = list
        for i in self.list:
            i.update(platform)

    def draw(self,window): # basic draw method contains all the methods to draw the sprites
        window.fill(globals.BLACK)
        window.blit((self.bg), (0, 0))
        self.drawlist(window, self.bgdecs)
        #self.drawlist(window, self.portals)
        self.player.draw(window)
        self.drawlist(window, self.sprites)
        self.drawlist(window, self.platforms)


    def platformlong(self, x, y, img, number):
        # number to make repeats of a platform
        instances = []
        if x == 'right':  # simple extra code to make level design easier
            x = globals.WIDTH - img.get_width()
        if y == 'floor':
            y = globals.HEIGHT - img.get_height()
        while number > 0:
            instance = sprites.Tile(x, y, img)
            instances.append(instance)
            x += img.get_width()
            number -=1
        return(instances)
class Stage1(Stages):
    def __init__(self):
        self.nextstage = None
        super().__init__()
        self.bg = pygame.Surface.convert(frames.cave2)
        self.player = sprites.Player(75, 300) # player starting coords

        self.bat1 = sprites.Bat(500,200)
        self.bat2 = sprites.Bat(800,100)


        self.sprites = [self.bat1,self.bat2] # '\_(~_~)_/`

#defining my different platform tiles4

        self.row1 = [sprites.Tile(0, 'floor', terrain.module1), sprites.Tile(300, 'floor', terrain.module3), sprites.Tile(716, 'floor', terrain.module4)] + self.platformlong(418, 'floor', terrain.blank1, 3)

        self.row2 = [sprites.Tile(364, 512, terrain.module2), sprites.Tile(780, 512, terrain.outsidecornerright)] + self.platformlong(524, 512, terrain.longfloor, 2)

        self.island1 =[sprites.Tile(636, 250, terrain.cap_1), sprites.Tile(668, 250, terrain.chunk_3), sprites.Tile(700, 250, terrain.chunk3), sprites.Tile(764, 282, terrain.cap1)]

        self.island2 = [sprites.Tile(0, 200, terrain.standardtile), sprites.Tile(0, 296, terrain.basiccorner), sprites.Tile(-32, 264, terrain.tidbit), sprites.Tile(160, 200, terrain.chunk2), sprites.Tile(224, 200, terrain.cap1)] + self.platformlong(32, 200, terrain.islandstrip, 4)

        self.island3 =[sprites.Tile(320, 175, terrain.cap_1), sprites.Tile(352, 175, terrain.chunk_2), sprites.Tile(384, 175, terrain.chunk4), sprites.Tile(447, 205, terrain.rnipple)]

        self.rightthing = [sprites.Tile(1046, 270, terrain.pointybit), sprites.Tile(1046, 334, terrain.stick), sprites.Tile(950, 398, terrain.widget), sprites.Tile(1078, 398, terrain.chunk4), sprites.Tile(1140, 430, terrain.rnipple), sprites.Tile(1014, 462, terrain.tidbit), sprites.Tile(1014, 494, terrain.leg), sprites.Tile(1014, 558, terrain.cap2)]

        self.corner = [sprites.Tile(0, -38, terrain.chunk4), sprites.Tile(63, -6, terrain.rnipple)]
        self.platforms = self.row1 + self.row2 + self.rightthing + self.island1 + self.island2 + self.island3 + self.corner

        self.wall = [sprites.Tile(-40, 50, frames.wallcrumb), sprites.Tile(-40, 100, frames.wallcrumb), sprites.Tile(-40, 150, frames.wallcrumb),sprites.Tile(-20, 168, frames.wallcrumb),sprites.Tile(30, 180, frames.wallcrumb), sprites.Tile(0, 130, frames.doorway)]
        self.bgdecs = self.wall

        #self.doorway = sprites.Portals(0,0, frames.doorway)
        self.portals = []
class GameOver(Stages):
    def __init__(self):
        self.tick = 0
        self.nextstage = None
        super().__init__()
        self.bg = frames.gameover
        self.imgs = []
        self.game = pygame.Surface.convert(frames.game)
        self.over = pygame.Surface.convert(frames.over)

    def draw(self,window): # basic draw method contains all the methods to draw the sprites
        self.game.set_colorkey((0, 0, 0))
        self.over.set_colorkey((0, 0, 0))
        self.tick +=1
        if self.tick < 30: #blits the words one at a time for cool
            window.blit((self.game), (380, 160))
        elif self.tick < 70:
            window.blit((self.game), (380, 160))
            window.blit((self.over), (380, 350))
        else:
            window.fill(globals.BLACK)
            window.blit((self.game), (380, 160))
            window.blit((self.over), (380, 350))

    def update(self):
        pass
    def inputs(self,event):
        pass

