import pygame
import globals
import states

class Main():
    def __init__(self):
        # game width and height set to global values
        self.WIDTH = globals.WIDTH
        self.HEIGHT = globals.HEIGHT
        # sets pygame window created to specified dimensions
        self.window = pygame.display.set_mode((self.WIDTH,self.HEIGHT))
        # initialises pygame clock (ticker)
        self.ticker = pygame.time.Clock()
        # sets nextscreen to loading screen to start chain of game states
        self.screen = states.Titel_Screen()
        # sets mouse invisible as a constant as for game mouse will
        # either not be there or replaced with my own cursor
        pygame.mouse.set_visible(False)
        # sets running so game can end
        self.running = True


    def main_loop(self):
        # start main loop
        while self.running == True:
            # sets frame rate, which I found to work best at 100 hertz
            self.ticker.tick(100)
             # collects events in pygame to prevent crahses and to be used for inputs
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # when QUIT game loop will cease
                    self.running = False
                # states specfic method for handling inputs
                self.screen.inputs(event)
            # states method - do, will contain methods for the updating and drawing
            self.screen.do(self.window)
            pygame.display.flip()
            # code for the changing of current state once state sets next state
            if self.screen.nextstate:
                self.screen = self.screen.nextstate()

        # closes pyagme once loop is complete
        pygame.quit()


pygame.init()
main = Main()
main.main_loop()
