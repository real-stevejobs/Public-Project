import pygame
import globals
import items
import stages


class States():
    def __init__(self):
        # sets default to title screen so worst case returns to menu
        self.nextsate = None


    def background_draw(self,window,img):
        # blits entered background onto background and resizes to fit
        img = pygame.image.load(img)
        bg_img = pygame.transform.scale(img, (globals.WIDTH, globals.HEIGHT))
        window.blit(bg_img,(0,0))

    def cursor(self,window): #https://lintnaya.itch.io/pixel-hand-gesture-asset
        img1 = pygame.image.load("Graphics/Cursor/Pointer.png")
        img1.set_colorkey((0, 0, 0))
        #img2 = pygame.image.load("")
        cursor_img = img1
        x,y = pygame.mouse.get_pos()
        window.blit(cursor_img, (x - cursor_img.get_width() // 4, y ))

    def draw_buttons(self,window):
        # method for all buttons
        for button in self.buttons :
            button.draw(window)
        self.cursor(window)
    def update_buttons(self):
        # method to check
        for button in self.buttons:
            button.button_colour()
    def do(self,window):
        self.update()
        self.draw(window)


class Titel_Screen(States):
    # displays loading image until player presses anything
    def __init__(self):
        super().__init__()
        self.nextstate = None
    def draw(self,window):
        # cureent loading screen image may change in later iterations when i start to prioritise aestetics
        self.background_draw(window, "Graphics/Backgrounds/Loading_screen.png")
    def inputs(self,event):
        # registers any key pressed to change state to menu
        if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
            self.nextstate = Menu
    def do(self,window):
        # complete laoding screen instruction as no need to update the static screen
        self.draw(window)

class Menu(States):
    def __init__ (self):
        super().__init__()
        self.nextstate = None # write about next state being bad
        # defining all my menu buttons
        button_startgame = items.Button('center', 100, 500, 100, "Start Game", 'black', 42, Game)
        button_user = items.Button('center', 280, 400, 80, "Users", 'black', 42, User_Menu)
        button_settings = items.Button('center', 380, 400, 80, "Settings", 'black', 42, Settings)
        button_quit = items.Button('center', 480, 400, 80, "Quit game",'black', 42, Quit)
        # placing my buttons in a list
        self.buttons = [button_startgame, button_user, button_settings, button_quit]
    def inputs(self,event):
        # method to update nextstate when button is pressed
        for button in self.buttons:
            if event.type == pygame.MOUSEBUTTONDOWN:
                action = button.mouse_click(event)
                if action != None:
                    self.nextstate = action
                    print(self.nextstate)
    def update(self):
        # method from button class to update button hovering appearance
        self.update_buttons()
    def draw(self,window):
        window.fill(globals.GRAY)
        self.draw_buttons(window)

    def do(self,window):
        self.update()
        self.draw(window)

class User_Menu(States):
    def __init__ (self):
        super().__init__()
        self.nextstate = None # write about next state being bad

        self.title = ((pygame.font.Font(None, 72)).render("Users", True, globals.WHITE))
        # defining all my menu buttons

        self.createuser = items.Button('center', 380, 400, 80, "Create user", 'gray', 42, None)
        self.menu = items.Button('center', 480, 400, 80, "Menu",'gray', 42, Menu)
        # placing my buttons in a list
        self.buttons = [self.createuser, self.menu]

    def inputs(self,event):
        # method to update nextstate when button is pressed
        for button in self.buttons:
            if event.type == pygame.MOUSEBUTTONDOWN:
                action = button.mouse_click(event)
                if action != None:
                    self.nextstate = action
                    print(self.nextstate)
    def update(self):
        # method from button class to update button hovering appearance
        self.update_buttons()
    def draw(self,window):
        window.fill(globals.GRAY)
        window.blit(self.title,(510,60))
        self.draw_buttons(window)

class Settings(States):
    def __init__ (self):
        super().__init__()
        self.nextstate = None # write about next state being bad

        self.title = ((pygame.font.Font(None, 72)).render("Settings", True, globals.WHITE))
        #defining all my lovley buttons
        deleteuser = items.Button('center', 180, 500, 80, "Delete User", 'gray', 42, None)
        brightness = items.Button('center', 280, 400, 80, "Brightness", 'gray', 42, None)
        volume = items.Button('center', 380, 400, 80, "Volume", 'gray', 42, None)
        difficulty = items.Button('center', 480, 400, 80, "Difficulty", 'gray', 42, None)
        returnmenu = items.Button('center', 560, 400, 80, "Return to menu", 'gray', 42, Menu)



        # buttons in a list for handling
        self.buttons = [brightness, volume, difficulty, deleteuser,returnmenu]

    def inputs(self,event):
        # method to update nextstate when button is pressed
        for button in self.buttons:
            if event.type == pygame.MOUSEBUTTONDOWN:
                action = button.mouse_click(event)
                if action != None:
                    self.nextstate = action
                    print(self.nextstate)
    def update(self):
        # method from button class to update button hovering appearance
        self.update_buttons()
    def draw(self,window):
        window.fill(globals.GRAY)
        window.blit(self.title,(510,60))
        self.draw_buttons(window)

    def do(self,window):
        self.update()
        self.draw(window)
class Game(States):
    def __init__(self):
        self.nextstate = None # write about next state being bad
        self.stage = stages.Stage1() #wil work with stages class to set to curent game stage when playing
    def inputs(self,event):
        self.stage.inputs(event) #passes events into game stage input method
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.nextstate = Menu #escape to menu with escape
    def do(self, window):
        self.stage.update()
        self.stage.draw(window) #passes window into stage draw funtion
        if self.stage.nextstage: #will update game stage if stage changes
            print("dm")
            self.stage = self.stage.nextstage()

class Quit(States):
    pass
