import pygame

WIDTH = 1216
HEIGHT = 640

FRAMERATE = 100

TRANSPARANT = (255,0,0,128)
GRAY = (26, 40, 56)
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)
MAGENTA = (255,0,255)
CYAN = (0,255,255)

GRAVITY = 0.0981

def setscreen(WIDTH, HEIGHT):
    return (pygame.display.set_mode((WIDTH, HEIGHT)))

def drawTextcenter(text, font, screen, x, y, w, h, text_colour):
    x = x + w / 2
    y = y + h / 2
    #font = pygame.font.("DejaVu Sans", 32)
    screen.blit(text)



