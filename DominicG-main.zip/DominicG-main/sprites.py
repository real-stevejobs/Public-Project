import pygame
import pygame.sprite
import frames
import globals
import random
import stages
import states

class Allsprite(pygame.sprite.Sprite): #inheriting from pygames sprites libary
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.xmomentum = 0
        self.ymomentum = 0
        self.attributes = []
        self.developtic = 0 #temp tic using for deveopment mode
        self.xcollide = 0
        self.ycollide = 0
        self.xdirection = 1

    def facing(self,img):
        if self.xdirection == -1: #flips image based on sprite direction
            img = pygame.transform.flip(img, True, False)
        return img
    def animate(self, frames, speed):
        try: #try added to prevent failure once frames are run through
            self.img = self.facing(frames[int(self.count)])
            self.count += speed
            if self.count > len(frames):
                self.count = 0
        except IndexError:
            self.count = 0

    def animate_indef(self, frames, speed):
        try: #try added to prevent failure once frames are run through
            self.img = self.facing(frames[int(self.count)])
            self.count += speed
            self.count = min(self.count, len(frames) - 1) #stop loop after final frame
        except IndexError:
            self.count = 0
    def hitbox(self,window):
        pygame.draw.rect(window, (255, 0, 0), self.rect, width = 1)
    def developmentmode(self,window): #feature i addeed to help with development hitboxes coord etc
        font = pygame.font.Font(None, 36)
        text_color = (255, 255, 255)
        y = 10
        for item in self.attributes:
            string = str(item).replace("self.","")
            name_text = font.render(string, {item}, True, text_color)
            window.blit(name_text, (pygame.display.Info().current_w - name_text.get_width() - 10, y))
            y += 20

    def draw(self,window):
        self.img.set_colorkey((0, 0, 255))#stanbdard sprite blit code
        window.blit(self.img, (self.x, self.y))
        #self.hitbox(window)


    def physicsy(self, platform):
        if self.rect.bottom < platform.rect.top + 10: #for detecting player falling through platform
            self.air = False
            self.jumpcount = 0
            self.ymomentum = 0
            self.rect.bottom = platform.rect.top #sets player ontop of platform
        elif self.rect.top < platform.rect.bottom + 1 and self.rect.top > platform.rect.bottom - 5:
            self.ymomentum = 1 #sets player beneath platform to stop jumping through
            self.rect.top = platform.rect.bottom + 10

    def physicsx(self, platform):
        lb = platform.rect.left - 5
        rb = platform.rect.right + 5
        if self.rect.right  > lb and self.rect.right < lb + 10: #moving right
            self.xcollide = 1
            self.rect.right = lb # -5 buffer to prevent getting stuck
            self.xmomentum = 0 #stops player from phassing through left of platform
        if self.rect.left < rb and self.rect.left > rb - 10: #moving left
            self.xcollide =-1
            self.rect.left = rb # +5 buffer
            self.xmomentum = 0 #stops player from phassing through right of platform
    def physics(self,platforms):
        yinline = False
        xinline = False
        for platform in platforms:
            count = 2
            if self.rect.colliderect(platform.rect):
                while count < 65 and xinline == False:
                    y = count + self.rect.y
                    if y > platform.rect.top and y < platform.rect.bottom:
                        xinline = True #decides that the player is within y and boundaries of platform
                    count += 8
                if self.rect.left + 1 < platform.rect.right and self.rect.right - 1 > platform.rect.left:
                    yinline = True #decides that the player i within x and boundaries of platform
                if xinline == True:
                    pass
                    self.physicsx(platform)
                if yinline == True :
                    self.physicsy(platform)
        if xinline == False:
            self.xcollide = 0
        if self.air == True: #accelerates player down
            self.ymomentum += globals.GRAVITY
        if yinline == False: #sets physics going if player is in the air
            self.air = True


class Player(Allsprite):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.img = frames.idle #default frame
        self.count = 0
        self.timer = 0
        self.speed = 2
        self.move = 0
        self.jump = False #different actionsdd
        self.attack = False
        self.air = False
        self.jumpcount = 0
        self.spacedown = False
        self.dynojump = False
        self.dash = False #different actions
        self.dashcount = 0
        self.moveframes = frames.walk


    def inputs(self,event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: #checks for left click
            self.attack = True
            self.count = 0
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3: #checks for right click
            self.dash = True
        else: #ensures attack isnt happening for other actions to occur
            if event.type == pygame.KEYDOWN and self.attack == False:
                if event.key == pygame.K_d and self.xcollide != 1: #ensures player is not colliding with a platform on right
                    self.xdirection = 1
                    self.xcollide = 0
                    self.move = 1
                elif event.key == pygame.K_a and self.xcollide != -1: #ensures player is not colliding with a platform on left
                    self.xdirection = -1
                    self.xcollide = 0
                    self.move = 1
                if event.key == pygame.K_LSHIFT and self.air == False:
                    self.speed = 3
                if event.key == pygame.K_SPACE and self.air == False: #stops double jumping
                    self.count = 0
                    self.dynojump = True
                    self.spacedown = True
                    self.jump = True


        if event.type == pygame.KEYUP:
            if event.key == pygame.K_d and self.xdirection == 1 or event.key == pygame.K_a and self.xdirection == -1:
                self.move = 0
            if event.key == pygame.K_SPACE:
                self.spacedown = False
            if event.key == pygame.K_LSHIFT:
                    self.speed = 2
    def dynamicjump(self): #neat little function that allows user to controll how long to jump for
        self.jumpcount +=1
        if self.jumpcount >= 40:
            self.dynojump = False
        if self.dynojump == True and self.ymomentum < 1:
            self.ymomentum = -4 + self.jumpcount * 0.05 #formula supplements physics in prolonged jumps
    def dojump(self): #pretty self-explanatory
        self.air = True
        self.attack = False
        if self.ymomentum < 0: #makes sure jump animation only plays while player is moving up
            self.animate_indef(frames.jump, 0.1)

    def draw(self,window):
        self.img.set_colorkey((0, 0, 255))
        window.blit(self.img, (self.rect.x -55, self.rect.y-22)) #draws player image so it is over hit box
        #self.developmentmode(window) #development mode i used to work on hitboxes
        #self.hitbox(window)
    def attacking(self,sprites): #pretty self-explanatory
        if self.air == False:
            self.xmomentum = 0
        self.animate(frames.swipe, 0.08)
        self.timer += 1
        if self.timer >= 30 and self.timer <= 40:
            self.attackrect = pygame.Rect(self.x + 82, self.y + 33, (self.xdirection * 75), 40)
            #print(self.attackrect)
        if self.timer >= 50:
            self.attack = False
            self.timer = 0

    def fall(self): #pretty self-explanatory
        if self.ymomentum == 0 and self.air == True: #checks for player falling
            self.count = 0
        if self.ymomentum > 0 :
            self.jump = False #stops jump animation
            self.animate_indef(frames.fall, 0.1)

    def actioncheck(self): #i use this to stop overlapping actions
        if self.air == True or self.attack == True:
            self.action = True
        else:
            self.action = False

    def dowalk(self): #pretty self-explanatory
        if self.xmomentum != 0:
            self.animate(self.moveframes, 0.1)

    def attribute_ticker (self): # part of my development mode code lets me see player attributes
        if self.developtic == 10:
            self.attributes = [self.rect.x, self.rect.y, self.jump, self.attack, self.air, self.xmomentum, self.ymomentum, self.xcollide, self.xdirection]
            self.developtic = 0
        self.developtic += 1

    def restage (self, potals): #changes game stage
        if self.rect.y > 650:
            return(stages.GameOver) #for falling death
        else:
            return(None)

    def update(self, platforms, sprites): #compiles all my update methods
        self.attribute_ticker()

        directionvalid = (self.xdirection - self.xcollide) * self.move
        self.xmomentum = directionvalid * self.speed #code validates user input and e
        self.y += self.ymomentum #moved this from inputs to update now far neater
        self.x += self.xmomentum

        self.rect = pygame.Rect(self.x +55, self.y + 22, 17, 64 ) #player hit box


        self.physics(platforms) #checks for the physics


        self.img = self.facing(frames.idle) #sets image simply
        self.actioncheck()
        self.fall() #fall is number 1 priority update check out of actions as others won't happen if falling
        if self.spacedown == True:
            self.dynamicjump()
        if self.speed == 3: #changes to sprint frames
            self.moveframes = frames.run
        else: #changes back
            self.moveframes = frames.walk
        if self.jump == True:
            self.dojump()
        if self.attack == True:
            self.attacking(sprites)
        elif self.xmomentum != 0 and self.action == False:
            self.dowalk() #animates walk when moving and not doing another animation

class Tile(Allsprite):
    def  __init__(self, x, y, img): #for platforms and background
        super().__init__(x, y)
        self.img = img
        self.width = img.get_width()
        self.height = img.get_height()
        if x == 'right':
            self.x = globals.WIDTH - img.get_width() # for setting tiles on top of screen
        if y == 'floor':
            self.y = globals.HEIGHT - img.get_height() # for setting tiles on bottom of screen
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)


class TileLong():
    def init__(self, x, y, img, number):
        self.number = number # number to make repeats of a platform
        self.img = img
        self.width = img.get_width()
        self.height = img.get_height() #automatically sets hitbox to image pos and size
        self.x = x
        self.y = y
        self.instances = []
        if x == 'right': #simple extra code to make level design easier
            self.x = globals.WIDTH - img.get_width()
        if y == 'floor':
            self.y = globals.HEIGHT - img.get_height()
        for i in self.number:
            instance = Tile(self.x, self.y, self.img)
            self.instances.append(instance)
            self.x += self.width



class Bat(Allsprite):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.img = frames.batforward[0]
        self.frames = frames.batforward
        self.count = 0
        self.speed_x = 0
        self.speed_y = 0
        self.Xdirection = random.choice([-1, 1]) #the different random values for bat movement
        self.Ydirection = random.choice([-1, 1])
        self.rect = self.img.get_rect()
    def update(self, platforms):
        #changes bats direction and speed accoding to the randomly asigned num
        self.x += self.speed_x * self.Xdirection
        self.y += self.speed_y * self.Ydirection
        self.rect.x = self.x
        self.rect.y = self.y
        self.bounce(platforms)
        self.bounceywalls()
        self.update_direction()
        self.animate(self.frames, 0.1)

    def bounce(self, platforms): #bounces the bat off platform hitboxes
        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                self.Xdirection *= -1
                self.Ydirection *= -1
                break

    def bounceywalls(self):#bounces the bat off window walls to keep it within the game window
        if self.x <= 0 or self.x >= globals.WIDTH - self.rect.width:
            self.Xdirection *= -1
        if self.y <= 0 or self.y >= globals.HEIGHT - self.rect.height:
            self.Ydirection *= -1

    def update_direction(self):
        if random.random() < 0.02: #randonly decides to update bat direction
            if random.random() < 0.5:
                self.frames = frames.batforward
                self.speed_x = 0
                self.speed_y = 0
            else: #selection here to prevent bat moving too randomly
                self.frames = frames.batside #selects apropriate frames for bat for direction
                self.speed_x = random.random()*2.5
                if self.speed_x > 1:
                    self.speed_y = random.random()*1.8
                else:
                    self.speed_y = random.random()*2.5
                if self.speed_y / self.speed_x > 1.4:
                    self.frames = frames.batforward
                self.Xdirection *= -1
                self.Ydirection *= -1

class Portals():
    def __init__ (self,x, y, frames, stage):
        self.x = x
        self.y = y
        self.stage = stage
        self.frames = frames.portal
