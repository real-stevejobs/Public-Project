import pygame

#game background images
cave1 = pygame.transform.scale(pygame.image.load("Graphics/Backgrounds/Prettycave.png"),(1216,640))
cave2 = pygame.transform.scale(pygame.image.load("Graphics/Backgrounds/Cave2.png"),(1216,640))
cave3 = pygame.transform.scale(pygame.image.load("Graphics/Backgrounds/Cave3.png"),(1216,640))

gameover = pygame.image.load("Graphics/Backgrounds/Game over.png")
game = pygame.transform.scale(pygame.image.load("Graphics/Backgrounds/Gameword.png"), (400,180))
over = pygame.transform.scale(pygame.image.load("Graphics/Backgrounds/Overword.png"), (400,180))
wallcrumb = pygame.image.load("Graphics/BGdecoration/wallcrum.png")
doorway = pygame.image.load("Graphics/Other Sprites/Items/doorway.png")
idle = pygame.image.load('Graphics/Player sprites/Idle.png') #player not walking image

walk = [] #walking animation frames
walk.append(pygame.image.load('Graphics/Player sprites/Walk 1.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 2.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 3.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 4.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 5.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 6.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 7.png'))
walk.append(pygame.image.load('Graphics/Player sprites/Walk 8.png'))

run = [] #run animation frames
run.append(pygame.image.load('Graphics/Player sprites/Run 1.png'))
run.append(pygame.image.load('Graphics/Player sprites/Run 2.png'))
run.append(pygame.image.load('Graphics/Player sprites/Run 3.png'))
run.append(pygame.image.load('Graphics/Player sprites/Run 4.png'))
run.append(pygame.image.load('Graphics/Player sprites/Run 5.png'))
run.append(pygame.image.load('Graphics/Player sprites/Run 6.png'))
run.append(pygame.image.load('Graphics/Player sprites/Run 7.png'))

swipe = [] #attack animation frames
swipe.append(pygame.image.load('Graphics/Player sprites/Swipe 1.png'))
swipe.append(pygame.image.load('Graphics/Player sprites/Swipe 2.png'))
swipe.append(pygame.image.load('Graphics/Player sprites/Swipe 3.png'))
swipe.append(pygame.image.load('Graphics/Player sprites/Swipe 4.png'))

jump = [] #jump animation frames
jump.append(pygame.image.load('Graphics/Player sprites/Jump 1.png'))
jump.append(pygame.image.load('Graphics/Player sprites/Jump 2.png'))
jump.append(pygame.image.load('Graphics/Player sprites/Jump 3.png'))

fall = [] #falling animation frames
fall.append(pygame.image.load('Graphics/Player sprites/Fall 1.png'))
fall.append(pygame.image.load('Graphics/Player sprites/Fall 1.png'))
fall.append(pygame.image.load('Graphics/Player sprites/Fall 1.png'))
fall.append(pygame.image.load('Graphics/Player sprites/Fall 2.png'))
fall.append(pygame.image.load('Graphics/Player sprites/Fall 2.png'))
fall.append(pygame.image.load('Graphics/Player sprites/Fall 3.png'))

batforward = [] #bat facing front animation frames
batforward.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Forward 1.png'))
batforward.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Forward 2.png'))
batforward.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Forward 3.png'))
batforward.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Forward 2.png'))

batside = [] #bat facing side on animation frames
batside.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Right 1.png'))
batside.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Right 2.png'))
batside.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Right 3.png'))
batside.append(pygame.image.load('Graphics/Other Sprites/Bat/Bat Right 2.png'))
